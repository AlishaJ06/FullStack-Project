const API_URL = "http://localhost:4000";

export { API_URL };
